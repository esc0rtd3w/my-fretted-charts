EOF v1.8b (c)2008-2010 T³ Software
----------------------------------

EOF is freeware and may be distributed freely (without charge). Please review
the license agreement contained in the file "license.txt" before proceeding to
use this program. If you do not accept the license agreement you may not use
this program.ble with the software and we'll see if we can resolve the problem.


Description
-----------

EOF is a song editor for the game Frets On Fire. Since playing the game I have
wanted to make my own songs but I was disappointed in the usability of other
software. I set out to make my own editor that makes song creation easy.


Installation
------------

Just unzip the archive into a user-writeable folder. Do not install EOF into
your "Program Files" or other system folders, especially if you are using
Windows Vista or Windows 7 as EOF will need to be able to create and modify
files in the folder in which it resides.


Usage
-----

Upon opening the EOF executable you are presented with a blank screen. From
here you can load an existing song or create a new one. If you are unfamiliar
with EOF you should read the included manual by clicking "Help->Manual" in the
menu. You can also look at the basic control by clicking "Help->Keys" in the
menu.
