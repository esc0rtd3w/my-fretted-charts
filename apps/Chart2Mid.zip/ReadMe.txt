Tool developed by Leff

Original thread:
http://www.scorehero.com/forum/viewtopic.php?t=45092

Tool is not actively developed anymore.

Use either the exe or jar version, whichever works for you.