

installation

 - the plugin, manual.rtf and warnings.txt go to plugins\fruity\generators\buzz generator adapter
 - dsplib.dll goes to fruityloops root dir

